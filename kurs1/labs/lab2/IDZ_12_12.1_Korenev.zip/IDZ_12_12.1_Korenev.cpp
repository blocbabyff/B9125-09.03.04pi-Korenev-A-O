#include <iostream>

using namespace std;

int main() {
    unsigned int F;
    cout << "vvedite 10-oe F (zashifrovanaya informatcia): ";
    cin >> F;

    unsigned int flightNumber = (F >> 8) & 0xFF;

    bool isIncoming = ((F >> 7) & 1) == 1;
    bool hasTransitOutput = ((F >> 3) & 1) == 1;
    bool hasSpecialFood = ((F >> 2) & 1) == 1;
    bool hasTransitBaggage = ((F >> 1) & 1) == 1;
    bool hasAnimals = ((F >> 0) & 1) == 1;

    cout << "\n--- results ---" << endl;
    cout << "nomer reisa: " << flightNumber << endl;
    cout << "type reisa:   " << (isIncoming ? "priletaushiy" : "uletayshiy") << endl;

    bool condition1 = isIncoming && hasTransitOutput && hasTransitBaggage;
    bool condition2 = !isIncoming && hasAnimals;
    bool condition3 = !isIncoming && hasSpecialFood;

    cout << "\n--- usloviya ---" << endl;

    if (condition1 || condition2 || condition3) {
        cout << "istina (uslovie vipolneno)" << endl;

        cout << "srabotalo: ";
        if (condition1) cout << "[transit passanger + bagash na pribivaushem reise] ";
        if (condition2) cout << "[Zivotnie] ";
        if (condition3) cout << "[osoboe pitanie] ";
        cout << endl;
    }
    else {
        cout << "result: false (ni odno ne vipolneno)" << endl;
    }
}