#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <set>

using namespace std;

struct mag {
    string magaz;
    string eda;
    string kolvo;
};

bool numss(string strr) {
    set<char> nums = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    int cc = 0;
    for (int n : strr) {
        if (nums.count(n) == 1) {
            cc++;
        }
        if (cc == strr.length()) return 1;
    }
    return 0;
}

bool wordz(string strr) {
    for (int i = 0; i < strr.length(); i++) {
        if ((strr[i] >= 'A' && strr[i] <= 'Z') || (strr[i] >= 'a' && strr[i] <= 'z'));
        else return 0;
    }
    return 1;
}

int main() {
    string outf;
    cout << "vvedite imya faila dlya sohraneniya resultata: ";
    cin >> outf;

    ofstream vivod(outf);
    if (!vivod.is_open()) {
        cout << "ne udalos sozdat fail dlya vivoda!" << endl;
        return 0;
    }

    vector<mag> spisok;
    ifstream fail("data.txt");
    if (!fail.is_open()) {
        cout << "net faila" << endl;
        return 0;
    }
    if (fail.eof()) {
        cout << "fail pust!" << endl;
        return 0;
    }
    string line;
    mag temp;
    int cc = 0;
    while (getline(fail, line)) {
        cc++;
        if (line.empty()) continue;
        stringstream ss(line);
        string lishnee;
        if ((ss >> temp.eda >> temp.magaz >> temp.kolvo) && !(ss >> lishnee)) {
            if (wordz(temp.eda) && wordz(temp.magaz) && numss(temp.kolvo)) {
                spisok.push_back(temp);
            }
            else cout << "oshibka v " << cc << " stroke" << endl;
        }
        else cout << "oshibka v " << cc << " stroke" << endl;
    }
    if (spisok.empty()) {
        cout << "plohoy fail" << endl;
        return 0;
    }
    fail.close();
    int kolvomagazov;
    string tempmag = spisok[0].magaz;
    vector<string> spmag;
    for (auto item : spisok) {
        if (count(spmag.begin(), spmag.end(), item.magaz) == 0) {
            spmag.push_back(item.magaz);
        }
    }
    kolvomagazov = spmag.size();

    set<string> eda1;
    for (int i = 0; i < spisok.size(); i++) {
        eda1.insert(spisok[i].eda);
    }

    set<string> vezde;
    set<string> nigde;
    tempmag = spisok[0].magaz;
    for (string odin : eda1) {
        set<string> magaz_s_tovarom;
        for (int i = 0; i < spisok.size(); i++) {
            if (spisok[i].eda == odin && stoi(spisok[i].kolvo) > 0) {
                magaz_s_tovarom.insert(spisok[i].magaz);
            }
        }

        if (magaz_s_tovarom.size() == kolvomagazov) {
            vezde.insert(odin);
        }
        if (magaz_s_tovarom.size() == 0) {
            nigde.insert(odin);
        }
    }

    cout << "est` v kazdom magazine: ";
    vivod << "est` v kazdom magazine: ";
    if (vezde.empty()) {
        cout << "takih net";
        vivod << "takih net";
    }
    else {
        for (string p : vezde) {
            cout << p << " ";
            vivod << p << " ";
        }
    }
    cout << endl;
    vivod << endl;

    cout << "net nigde: ";
    vivod << "net nigde: ";
    if (nigde.empty()) {
        cout << "takih net";
        vivod << "takih net";
    }
    else {
        for (string p : nigde) {
            cout << p << " ";
            vivod << p << " ";
        }
    }
    cout << endl;
    vivod << endl;

    int kolvotovarov = 0;
    vector<int> sptov;
    for (int i = 0; i < spmag.size(); i++) {
        int k_tovarov = 0;
        for (int j = 0; j < spisok.size(); j++) {
            if (spisok[j].magaz == spmag[i]) {
                k_tovarov++;
            }
        }
        sptov.push_back(k_tovarov);
    }

    int top1 = 0;
    int top2 = 0;
    int top3 = 0;
    for (int n : sptov) {
        if (n > top1) top3 = top2, top2 = top1, top1 = n;
        else if (n > top2) top3 = top2, top2 = n;
        else if (n > top3) top3 = n;
    }
    cout << "naibol`shiy assortiment:" << endl;
    vivod << "naibol`shiy assortiment:" << endl;

    int ccc = 0;
    for (int n : sptov) {
        if (n == top1 && top1 != 0) {
            cout << "1 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
            vivod << "1 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
        }
        else if (n == top2 && top2 != 0) {
            cout << "2 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
            vivod << "2 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
        }
        else if (n == top3 && top3 != 0) {
            cout << "3 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
            vivod << "3 mesto: " << spmag[ccc] << " (tovarov: " << n << ")" << endl;
        }
        ccc++;
    }

    vivod.close();
    return 0;
}